window.onload = function(){
    start();
}

function start(){
    document.getElementById("box").style.display = "block";
    preset();
    assignButtons();
}