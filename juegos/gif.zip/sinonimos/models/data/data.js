
export const data = [
    {
        opciones: [
            'Rugoso',
            'Áspero',
            'Tenaz',
            'Corrugado',
            'Suave',
        ],
        respuesta: 'Suave'
    },

    {
        opciones: [
            'Enredo',
            'Problema',
            'Confusión',
            'Solución',
            'Incertidumbre',
        ],
        respuesta: 'Solución'
    },

    {
        opciones: [
            'Bronce',
            'Aluminio',
            'Hierro',
            'Cobre',
            'Madera',
        ],
        respuesta: 'Madera'
    },

    {
        opciones: [
            'Asado',
            'Picada',
            'Chocotorta',
            'Pizza',
            'Hamburguesa',
        ],
        respuesta: 'Chocotorta'
    },

    {
        opciones: [
            'Tizne',
            'Mancha',
            'Suciedad',
            'Barro',
            'Blanco',
        ],
        respuesta: 'Blanco'
    },

    {
        opciones: [
            'Esfumarse',
            'Esconderse',
            'Mostrarse',
            'Desaparecer',
            'Evaporarse',
        ],
        respuesta: 'Mostrarse'
    },
]
