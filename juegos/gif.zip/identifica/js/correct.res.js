const CORRECTRES = [
    "PALANCA",
    "MENTON",
    "PRIMO",
    "SUBTE",
    "OMBLIGO",
    "COMERCIAL",
    "SALMON",
    "PARPADO",
    "CUERO",
    "MIEDO"
]