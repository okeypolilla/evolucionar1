window.onload = function(){
    reset();
}

function reset(){
    document.getElementById("box").style.display = "block";
    preset();
    assignButtons();
}