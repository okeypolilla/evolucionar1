
let letras=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]  //letras 26 // para for 25
let G=0;
let P=0;
let numero=[];
let vuelta=[];
let palabra= [];
let guarda2= [];

positionR=Math.floor(Math.random() * (15));    //selecciona la letra a repetir 

window.onload = function(){
  
var cantidadNumeros = 15;                                                                    
var myArray = [];                                                         
while(myArray.length <cantidadNumeros ){
  var numeroAleatorio = Math.ceil(Math.random()*cantidadNumeros);
  var existe = false;
  for(var i=0;i<myArray.length;i++){
	if(myArray [i] == numeroAleatorio){
        existe = true;
        break;
    }
  }
  if(!existe){
    myArray[myArray.length] = numeroAleatorio;
  }

}
let num2=Math.floor(Math.random() * (10));
for(var a=0;a<15;a++){
        if(myArray [a] == positionR){
            myArray[num2]=positionR;
            break;
        }
      }
    
   for (let h = 0; h <15; h++) {
    palabra[h]=letras[myArray[h]];
   }

for (let h = 0; h <15; h++) {
    	palabra[h]=letras[myArray[h]];
   }
document.getElementById('cont1').innerHTML='<h1 class="body" style="color:white;">'+palabra.join(" ");

  }

function revisar()
{

let revisa=document.getElementById("texto").value;
revisa=revisa.toUpperCase();

if(letras[positionR]==revisa)
{
G++
let elemento1=document.getElementById("b2");
elemento1.style.display="none";
let elemento2=document.getElementById("texto");
elemento2.style.display="none";
document.getElementById('cont1').innerHTML="<h1>CORRECTO</h1>";
	_SWin();


}else{
    P++
    let elemento1=document.getElementById("b2");
    elemento1.style.display="none";
    let elemento2=document.getElementById("texto");
    elemento2.style.display="none";
    document.getElementById('cont1').innerHTML="<h1>INCORRECTO</h1>";
    	_SLose();


}


if(G+P<=4)
{
    let elementox=document.getElementById("este");
    elementox.style.display="block";   
}else{
    document.getElementById('cont1').innerHTML="<h1>PUNTUACION</h1>" + " "+ G + "/5";
    let elementox=document.getElementById("volver");
    elementox.style.display="block";   
	G=0
	P=0	
}


}